package com.hc.lolmatchhistory.dto;

import lombok.Data;

@Data
public class SummonerInfoResponseDTO {
    private SummonerDTO summoner;
//    private LeagueEntryDTO soloRank;
}