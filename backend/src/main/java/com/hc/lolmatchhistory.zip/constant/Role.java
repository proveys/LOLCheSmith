package com.hc.lolmatchhistory.constant;

public enum Role {
    USER,
    ADMIN
}